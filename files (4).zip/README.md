```markdown
# TutorSwipe (Website-first) — Django Starter

This is a website-first TutorSwipe starter using Django. It implements:
- User registration & simple auth (Django auth)
- User profiles (Student / Teacher)
- Swipe feed: students can swipe through teacher cards (right = like, left = skip)
- Store swipes and auto-create a match when both sides like each other or teacher has auto_accept
- Matches list and a simple chat page per match (non-real-time, messages stored in DB)
- Templates and basic styling with a Tinder-like card UI (client-side JS)

Getting started (local):
1. Create a Python 3.10+ virtualenv:
   python -m venv venv
   source venv/bin/activate  # macOS / Linux
   venv\Scripts\activate     # Windows

2. Install dependencies:
   pip install -r requirements.txt

3. Run migrations & create superuser:
   python manage.py migrate
   python manage.py createsuperuser

4. Start dev server:
   python manage.py runserver

5. Open: http://127.0.0.1:8000/

Project notes:
- DB: default SQLite for dev. For production switch to PostgreSQL.
- For real-time chat: add Django Channels and Redis (instructions in README_EXTEND.md).
- For file uploads (profile photos): configure MEDIA_ROOT and a storage backend (S3, etc.) in production.
- For deploying: recommended to use Gunicorn + Nginx (or a PaaS like Render/Heroku) and a managed PostgreSQL.

What to do next:
- Enable email verification and password reset
- Add teacher availability calendar
- Add payments (Stripe or local provider)
- Add FCM or Web Push notifications (requires additional frontend & service workers)
- Add Django Channels with Redis for real-time chat

If you want I can:
- Extend this with Django Channels + WebSocket chat
- Add a simple admin dashboard for teachers
- Add geolocation searching and filters (distance-based)
```