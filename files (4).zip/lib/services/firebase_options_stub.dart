// Replace this stub by generating options via FlutterFire CLI or fill manually
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions, defaultTargetPlatform, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    // TODO: Replace with real config
    return const FirebaseOptions(
      apiKey: 'REPLACE_ME',
      appId: 'REPLACE_ME',
      messagingSenderId: 'REPLACE_ME',
      projectId: 'REPLACE_ME',
      storageBucket: 'REPLACE_ME',
    );
  }
}